# PyInstaller spec for HorillaAgent.exe
# Run from the horilla-agent/ directory:
#   pyinstaller HorillaAgent.spec

from pathlib import Path

block_cipher = None

a = Analysis(
    ["main.py"],
    pathex=[str(Path(".").resolve())],
    binaries=[],
    datas=[
        ("assets/horilla_agent.ico", "assets"),
    ],
    hiddenimports=[
        # pywin32
        "win32timezone",
        "win32api",
        "win32con",
        "win32gui",
        "win32process",
        "win32crypt",
        # pynput
        "pynput.keyboard._win32",
        "pynput.mouse._win32",
        # pystray (system tray)
        "pystray",
        "pystray._win32",
        # uiautomation
        "uiautomation",
        "comtypes",
        "comtypes.client",
        "comtypes.gen",
        # psutil
        "psutil",
        # PIL / mss
        "PIL._imaging",
        "PIL.Image",
        "PIL.ImageDraw",
        "mss",
        "mss.windows",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    collect_all=["uiautomation", "comtypes", "pystray"],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="HorillaAgent",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon="assets/horilla_agent.ico",
    version="assets/version_info.txt",
)
